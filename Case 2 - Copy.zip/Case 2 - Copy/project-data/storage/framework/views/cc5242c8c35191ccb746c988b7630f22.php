<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Alumni</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body{
            background:#f4f6f9;
        }

        .header{
            background:#003366;
            color:white;
            padding:20px;
            border-radius:15px 15px 0 0;
        }

        .card-custom{
            border:none;
            border-radius:15px;
            overflow:hidden;
            box-shadow:0 0 20px rgba(0,0,0,.08);
        }

        .section-title{
            color:#003366;
            font-weight:bold;
            border-left:5px solid #003366;
            padding-left:10px;
            margin-top:25px;
            margin-bottom:15px;
        }

        .label{
            font-weight:bold;
            color:#555;
        }

        .foto-alumni{
            width:220px;
            height:220px;
            object-fit:cover;
            border-radius:10px;
            border:4px solid #003366;
        }
    </style>
</head>
<body>

<div class="container py-5">

    <div class="card card-custom">

        <div class="header d-flex justify-content-between align-items-center">

            <div>
                <h2 class="mb-0">Detail Data Alumni</h2>
                <small>Himpunan Mahasiswa Elektro UNSRI</small>
            </div>

            <a href="<?php echo e(url('/dashboard')); ?>"
               class="btn btn-light">
                ← Kembali
            </a>

        </div>

        <div class="card-body p-4">

            <div class="row">

                <div class="col-md-4 text-center">

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($alumni->foto): ?>

                        <img src="<?php echo e(asset('storage/'.$alumni->foto)); ?>"
                             class="foto-alumni">

                    <?php else: ?>

                        <img src="https://via.placeholder.com/220"
                             class="foto-alumni">

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>

                <div class="col-md-8">

                    <h3 class="text-primary">
                        <?php echo e($alumni->nama_gelar); ?>

                    </h3>

                    <hr>

                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <div class="label">Angkatan</div>
                            <?php echo e($alumni->tahun_angkatan); ?>

                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="label">3 Digit NIM</div>
                            <?php echo e($alumni->nim_3_digit); ?>

                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="label">Jenis Kelamin</div>
                            <?php echo e($alumni->jenis_kelamin); ?>

                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="label">No HP</div>
                            <?php echo e($alumni->no_hp); ?>

                        </div>

                    </div>

                </div>

            </div>

            <h5 class="section-title">
                Data Pribadi
            </h5>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <div class="label">Tempat Lahir</div>
                    <?php echo e($alumni->tempat_lahir); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">Tanggal Lahir</div>
                    <?php echo e($alumni->tanggal_lahir); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">No WhatsApp</div>
                    <?php echo e($alumni->no_whatsapp); ?>

                </div>

            </div>

            <h5 class="section-title">
                Domisili
            </h5>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <div class="label">Provinsi</div>
                    <?php echo e($alumni->provinsi); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">Kota / Kabupaten</div>
                    <?php echo e($alumni->kota_kabupaten); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">Kecamatan</div>
                    <?php echo e($alumni->kecamatan); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">Kelurahan</div>
                    <?php echo e($alumni->kelurahan); ?>

                </div>

                <div class="col-12 mb-3">
                    <div class="label">Alamat Lengkap</div>
                    <?php echo e($alumni->alamat); ?>

                </div>

            </div>

            <h5 class="section-title">
                Pekerjaan Saat Ini
            </h5>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <div class="label">Institusi / Perusahaan</div>
                    <?php echo e($alumni->institusi); ?>

                </div>

                <div class="col-md-6 mb-3">
                    <div class="label">Jabatan</div>
                    <?php echo e($alumni->jabatan); ?>

                </div>

                <div class="col-12 mb-3">
                    <div class="label">Alamat Tempat Kerja</div>
                    <?php echo e($alumni->alamat_kerja); ?>

                </div>

            </div>

            <h5 class="section-title">
                Informasi Tambahan
            </h5>

            <div class="mb-4">
                <div class="label">Bidang Fokus Keahlian</div>
                <?php echo e($alumni->bidang_keahlian); ?>

            </div>

            <div class="mb-4">
                <div class="label">Hobi</div>
                <?php echo e($alumni->hobi); ?>

            </div>

            <div class="mb-4">
                <div class="label">Pesan dan Harapan</div>

                <div class="p-3 bg-light rounded">
                    <?php echo e($alumni->pesan_harapan); ?>

                </div>
            </div>

        </div>

    </div>

</div>

</body>
</html><?php /**PATH C:\Case 2\project-data\resources\views/admin/detail.blade.php ENDPATH**/ ?>